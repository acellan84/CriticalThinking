package criticalthinkingwkfour;

public abstract class Shape {
	//declaring surface area and volume methods
	public abstract double surfaceArea();
    public abstract double volume();
   }